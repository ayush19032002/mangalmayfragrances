import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { FaInstagram, FaFacebookF, FaWhatsapp, FaTwitter } from 'react-icons/fa';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navItems = [
    { name: 'Home', path: '/' },
    { name: 'Products', path: '/products' },
    { name: 'About Us', path: '/about' },
    { name: 'Contact Us', path: '/contact' }
  ];

  return (
    <footer className="bg-section-gray border-t border-divider pt-24 pb-12">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-16 mb-24">
          
          {/* Brand Info */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex flex-col items-start gap-3 no-underline mb-8">
               <img src="/logo-bg.png" alt="Mangalmay Logo" className="w-32 h-auto object-contain" />
            </Link>
            <p className="text-medium-gray leading-relaxed max-w-sm font-body font-normal text-sm">
              Bringing spirituality into your life and home since 2008. Crafted with traditional wisdom and modern minimalism.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-[0.65rem] uppercase tracking-[0.3em] font-bold mb-10 text-near-black">Quick Links</h4>
            <ul className="space-y-4 list-none p-0">
              {navItems.map(item => (
                <li key={item.name}>
                  <NavLink to={item.path} className="text-medium-gray hover:text-brand-red transition-all no-underline font-body text-xs font-bold uppercase tracking-widest">
                    {item.name}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Product Categories */}
          <div>
            <h4 className="text-[0.65rem] uppercase tracking-[0.3em] font-bold mb-10 text-near-black">The Collections</h4>
            <ul className="space-y-4 list-none p-0">
              {['Zipper Packs', 'Deep Dhoop', 'Family Bundles', 'Royal Jars'].map(style => (
                <li key={style}>
                  <Link to="/products" className="text-medium-gray hover:text-brand-red transition-all no-underline font-body text-xs font-bold uppercase tracking-widest">
                    {style}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact & Social */}
          <div>
            <h4 className="text-[0.65rem] uppercase tracking-[0.3em] font-bold mb-10 text-near-black">Stay Connected</h4>
            <div className="flex gap-4 mb-10">
              {[
                { icon: <FaInstagram />, link: '#' },
                { icon: <FaFacebookF />, link: '#' },
                { icon: <FaTwitter />, link: '#' },
                { icon: <FaWhatsapp />, link: 'https://wa.me/919904957696' }
              ].map((social, i) => (
                <a 
                  key={i} 
                  href={social.link} 
                  target="_blank"
                  className="w-12 h-12 rounded-full border border-near-black/10 flex items-center justify-center text-xl text-near-black/40 hover:bg-brand-red hover:text-white hover:border-brand-red transition-all duration-300"
                >
                  {social.icon}
                </a>
              ))}
            </div>
            <p className="text-medium-gray text-[0.6rem] font-bold uppercase tracking-widest leading-relaxed">
              Madhapar, Rajkot-360006<br />Gujarat, India
            </p>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="pt-10 border-t border-divider flex flex-col md:flex-row justify-between items-center gap-8">
          <p className="text-medium-gray/60 text-[0.6rem] uppercase tracking-[0.3em] font-bold">
            &copy; {new Date().getFullYear()} Mangalmay Fragrances. All Rights Reserved.
          </p>
          <button 
            onClick={scrollToTop}
            className="text-medium-gray hover:text-brand-red transition-all font-bold tracking-[0.2em] text-[0.6rem] uppercase"
          >
            Up to top ↑
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

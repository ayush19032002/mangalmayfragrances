import React from 'react';
import { motion } from 'framer-motion';

const TopSelling: React.FC = () => {
  const products = [
    { name: 'Kesar Chandan', weight: '200g', price: '₹140', image: '/product1.png' },
    { name: 'Exotica Heaven', weight: '110g', price: '₹80', image: '/product2.png' },
    { name: 'Roza Luxury', weight: '400g', price: '₹180', image: '/rose.png' },
    { name: 'Royal Magnet', weight: '200g', price: '₹140', image: '/hero.png' }
  ];

  const handleInquiry = (name: string) => {
    const message = encodeURIComponent(`Hi, I'm interested in inquiring about ${name}. Please provide more details.`);
    window.open(`https://wa.me/919904957696?text=${message}`, '_blank');
  };

  return (
    <section className="py-24 bg-white overflow-hidden">
      <div className="max-w-[1400px] mx-auto px-6">
        <div className="text-center mb-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
          >
            <h2 className="text-[clamp(2.2rem,4vw,3.2rem)] font-normal text-near-black leading-tight mb-3"
              style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>Top selling products</h2>
            <p className="section-subtitle">Experience an Ambience of Peace and Tranquility</p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-16 lg:gap-12">
          {products.map((p, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group flex flex-col items-center text-center p-6 lg:p-0"
            >
              {/* Floating Image (No Card Box) */}
              <div className="relative w-full aspect-square flex items-center justify-center mb-8 px-8 group-hover:-translate-y-2 transition-transform duration-500">
                <div className="absolute inset-x-8 inset-z-0 bottom-0 h-1/2 bg-section-gray/40 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity" />
                <img src={p.image} className="w-[85%] h-auto relative z-10 drop-shadow-2xl" alt={p.name} />
              </div>

              {/* Price Badge (Charcoal Pill) */}
              <div className="bg-near-black text-white px-6 py-1 text-[0.65rem] font-bold tracking-[0.2em] rounded-full mb-4 shadow-md group-hover:bg-brand-red transition-all duration-300">
                {p.price}
              </div>

              {/* Product Info */}
              <h3 className="text-[clamp(1.4rem,2vw,1.8rem)] font-normal text-near-black leading-tight mb-3"
                style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>{p.name}</h3>
              <p className="text-[0.6rem] font-black tracking-[0.2em] text-medium-gray mb-8 opacity-60 uppercase">{p.weight} • PREMIUM BLEND</p>

              {/* INQUIRE button - Visible on mobile/tablet, hover on desktop */}
              <button
                onClick={() => handleInquiry(p.name)}
                className="btn-primary !px-10 !py-3 !text-[0.65rem] lg:opacity-0 group-hover:opacity-100 transition-all duration-500 transform lg:translate-y-4 group-hover:translate-y-0"
              >
                INQUIRE NOW
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TopSelling;

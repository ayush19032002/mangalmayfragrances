import React, { useState } from 'react';
import ProductCard from './ProductCard';
import { motion, AnimatePresence } from 'framer-motion';

const ProductList: React.FC = () => {
  const [activeTab, setActiveTab] = useState('ALL');

  const tabs = ['ALL', 'ZIPPER PACKS', 'DHOOP STICKS', 'INCENSE STICKS JARS', 'LOOSE INCENSE STICKS'];
  
  const products = [
    // ZIPPER PACKS
    { id: 1, name: 'Sandalwood', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/product1.png', notes: 'Fragrance of Real Sandal' },
    { id: 2, name: 'Exotica Heaven', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/product2.png', notes: 'Perfumed Incense Sticks' },
    { id: 3, name: 'Keshar Essence', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/rose.png', notes: 'Fragrance of Real Saffron Threads' },
    { id: 4, name: 'Flower Bucket (4 in 1)', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/hero.png', notes: 'Rose • Lavender • Mogra • Ratrani' },
    { id: 5, name: 'Imperial Collection (4 in 1)', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/product1.png', notes: 'Heritage • Magnet • Velvet Touch • Fantasia' },
    { id: 6, name: 'Perfume Harmony (5 in 1)', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/product2.png', notes: 'Magic World • Blue Sea • Coolant • Celebration • Feelings' },
    { id: 7, name: 'Prathna', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/rose.png', notes: 'A Perfumed Devotional Fragrance' },
    { id: 8, name: 'Gugal', category: 'ZIPPER PACKS', price: '80', weight: '110g', image: '/hero.png', notes: 'A Scented Fragrance of Gugal' },

    // DHOOP STICKS
    { id: 9, name: 'Exotica Heaven', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/lavender.png', notes: 'Premium Dhoop Stick' },
    { id: 10, name: 'Kesar Chandan', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/product1.png', notes: 'Traditional Wood Scent' },
    { id: 11, name: 'Guggal', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/product2.png', notes: 'Natural Purification' },
    { id: 12, name: 'Sandal Wood', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/rose.png', notes: 'Pure Sandal Extract' },
    { id: 13, name: 'Kasturi', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/hero.png', notes: 'Exotic Musk Aroma' },
    { id: 14, name: 'Rose', category: 'DHOOP STICKS', price: '80', weight: '100g', image: '/lavender.png', notes: 'Classic Floral Calm' },

    // JARS
    { id: 15, name: 'Incense Sticks Jars', category: 'INCENSE STICKS JARS', price: '140', weight: '200g', image: '/product1.png', notes: 'Bulk Luxury Jar' },

    // LOOSE
    { id: 16, name: 'Loose Incense Sticks', category: 'LOOSE INCENSE STICKS', price: 'Contact', weight: '200g / 500g', image: '/hero.png', notes: 'Wholesale Packs Available' },
  ];

  const filteredProducts = activeTab === 'ALL' 
    ? products 
    : products.filter(p => p.category === activeTab);

  return (
    <div className="max-w-[1400px] mx-auto px-6 py-20 bg-white">
      {/* Tab Filter Bar */}
      <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-6 mb-24 border-b border-divider overflow-x-auto pb-4 scrollbar-hide">
        {tabs.map(tab => (
          <button 
            key={tab} 
            className={`pb-4 text-[0.65rem] font-bold tracking-[0.25em] transition-all relative whitespace-nowrap ${
              activeTab === tab 
              ? 'text-brand-red' 
              : 'text-medium-gray hover:text-near-black'
            }`}
            onClick={() => setActiveTab(tab)}
          >
            {tab}
            {activeTab === tab && (
              <motion.div 
                layoutId="activeTabUnderline"
                className="absolute bottom-0 left-0 w-full h-0.5 bg-brand-red"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            )}
          </button>
        ))}
      </div>

      {/* Product Grid */}
      <motion.div 
        layout
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-10 gap-y-20"
      >
        <AnimatePresence mode="popLayout" initial={false}>
          {filteredProducts.map((product, idx) => (
            <motion.div
              layout
              key={product.id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ 
                 duration: 0.4, 
                 ease: [0.22, 1, 0.36, 1],
                 delay: idx * 0.05 
              }}
            >
              <ProductCard 
                name={product.name}
                category={product.category}
                price={product.price}
                weight={product.weight}
                image={product.image}
                notes={product.notes}
              />
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Empty State */}
      {filteredProducts.length === 0 && (
        <div className="text-center py-20">
          <p className="text-medium-gray font-medium">No products found in this category.</p>
        </div>
      )}
    </div>
  );
};

export default ProductList;
